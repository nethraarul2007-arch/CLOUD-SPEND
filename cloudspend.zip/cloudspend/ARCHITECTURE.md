# CloudSpend Architecture

## Component diagram

```mermaid
flowchart TD
    U[User] --> UI[HTML / CSS / Browser JavaScript]
    UI -->|HTTP JSON requests| API[Node.js built-in HTTP server]
    API --> V[Validation layer]
    V --> C[Cost and budget calculations]
    C --> S[JSON file store]
    S --> D[(data/store.json)]
    API -->|State + calculated metrics| UI
    UI --> CH[Canvas chart / service breakdown]
    UI --> R[CSV report download]
    CSV[User CSV file] --> UI
    UI -->|Validated rows| API
```

## Main modules

- `public/index.html`: dashboard layout and forms.
- `public/styles.css`: responsive styling.
- `public/app.js`: calls API endpoints, renders metrics and charts, parses CSV and downloads a report.
- `src/server.js`: Node.js HTTP server, static file serving, request parsing, validation and API routes.
- `src/costs.js`: unit-cost calculation, daily/monthly aggregation, service totals, budget alert and run-rate forecast.
- `src/store.js`: initializes simulated data and reads/writes JSON persistence.
- `test/`: automated tests using `node:test` and `node:assert`.

## Request flow

1. The browser submits usage, pricing or budget settings as JSON.
2. The server validates fields and allowed ranges.
3. Valid data is persisted to `data/store.json`.
4. The server calculates totals from saved entries and current pricing.
5. The browser updates dashboard cards, charts, breakdown and ledger.
6. CSV import sends parsed rows for server-side validation; report export is generated in the browser.

## Core formulas

- Entry cost = usage quantity × configured price per unit.
- Daily cost = sum of entry costs whose date equals today.
- Month-to-date cost = sum of entry costs in the current calendar month.
- Budget utilization = month-to-date cost ÷ monthly budget × 100.
- Forecast = month-to-date cost ÷ day number today × total days in the current month.

The dashboard uses USD and sample prices only. The application does not query real cloud provider pricing or billing systems.
