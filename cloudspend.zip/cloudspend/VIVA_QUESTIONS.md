# CloudSpend Viva Questions and Answers

### 1. What is CloudSpend?
CloudSpend is a web application prototype that estimates cloud usage costs and provides budget alerts.

### 2. What problem does it address?
It helps users understand estimated costs from resource usage and identify when spending approaches a configured monthly budget.

### 3. Which technologies are used?
HTML, CSS, browser JavaScript and Node.js built-in modules. No third-party packages are required.

### 4. Why is Node.js used?
Node.js runs the server-side JavaScript, handles HTTP requests, validates input and reads/writes application data.

### 5. How is the cost calculated?
The system multiplies a usage quantity by the configured price per unit for that service.

### 6. How are daily and monthly costs different?
Daily cost includes entries dated today. Month-to-date cost includes entries dated within the current calendar month.

### 7. What is a budget alert?
It is a dashboard warning shown when month-to-date cost reaches the configured percentage threshold or exceeds the monthly budget.

### 8. How does the forecast work?
It divides current month-to-date cost by the current day of the month and multiplies that average by the total number of days in the month.

### 9. Is the forecast guaranteed to be accurate?
No. It is a simple run-rate estimate and assumes spending continues at the current average rate.

### 10. Where is application data stored?
The app saves data locally in `data/store.json`.

### 11. What is CSV import used for?
It allows usage records to be loaded from a CSV file with date, service and quantity columns, plus optional details.

### 12. What does the downloadable report contain?
It contains usage rows, unit prices, estimated costs, monthly budget, month-to-date spend and forecast.

### 13. Are the sample prices actual cloud prices?
No. They are illustrative placeholders in USD. The app does not connect to provider billing APIs.

### 14. What happens when a service price changes?
The saved usage records are recalculated using the current configured price for that service.

### 15. How is input validation performed?
The server checks that a service has configured pricing, the date uses the required format, quantity is positive, and prices/budget settings are within allowed ranges.

### 16. How can the project be tested?
Run `npm test` in the project directory. Tests use Node's built-in test runner.

### 17. How do you start the application?
Run `npm start` and open `http://localhost:3000` in a browser.

### 18. What are the main limitations?
It is a single-user demo with JSON persistence, no authentication, no live cloud billing integration and no external email/SMS alerts.

### 19. What is a possible future enhancement?
Integrate provider billing APIs, store data in a database, add user accounts, and send alerts by email.

### 20. Why are usage entries and pricing called simulated?
They are demonstration data for testing and learning, not records from a real cloud account.
