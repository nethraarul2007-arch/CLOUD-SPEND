# CloudSpend: Cloud Usage Cost Estimation and Budget Alert System

CloudSpend is a small, local educational web application for entering cloud resource usage, estimating costs from configurable unit prices, tracking daily/month-to-date spend, forecasting month-end cost, and alerting when a monthly budget threshold is reached.

## Features

- Add resource usage entries with date, provider, service, quantity, region and notes.
- Configure or update price per unit for each service.
- Calculate daily and calendar-month costs from usage × configured price.
- Monthly budget, remaining budget, configurable alert threshold and budget-overrun warning.
- Seven-day cost chart and monthly service-cost breakdown.
- Basic month-end run-rate forecast: month-to-date spend ÷ current day of month × days in month.
- CSV import with row validation and a downloadable CSV report.
- JSON file persistence in `data/store.json`.
- Built with HTML, CSS, browser JavaScript, and Node.js built-in modules only.
- Automated tests using Node's built-in test runner.

## Important: demo data and pricing

**All initial entries are simulated sample data.** They are marked `SIMULATED` in the ledger. The initial service rates are illustrative placeholders, not current AWS, Azure, Google Cloud, or any other provider's official prices. All costs are estimates in USD. Replace the sample prices with rates appropriate to your own scenario before relying on the results. This app does not connect to a real cloud account or billing API.

## Requirements

- Node.js 18 or newer (Node.js 20+ recommended)
- VS Code or another editor
- No third-party npm packages required

## Run in VS Code

1. Extract `cloudspend.zip`.
2. Open the extracted `cloudspend` folder in VS Code.
3. Open Terminal → New Terminal.
4. Check Node.js: `node --version`
5. Start the app:

   ```bash
   npm start
   ```

6. Open **http://localhost:3000** in your browser.
7. Stop the server with `Ctrl+C`.

No `npm install` is required because the project uses only Node.js built-in modules.

## Run tests

```bash
npm test
```

Tests cover unit-cost arithmetic, daily/monthly summaries, forecasting, budget alerts and usage validation.

## CSV import format

The CSV file must contain `date`, `service`, and `quantity` columns. Optional columns are `provider`, `resource`, `region`, and `note`.

```csv
date,provider,service,resource,quantity,region,note
2026-10-22,Demo Cloud,Compute,api-vm-01,12,ap-south-1,Example usage
2026-10-22,Demo Cloud,Storage,backup-bucket,30,ap-south-1,Daily storage
```

- Dates must use `YYYY-MM-DD`.
- The `service` value must exactly match a configured service name.
- Quantity must be a positive number.
- Rows that fail validation are skipped and counted in the import notice.
- CSV values are estimates using the service's currently configured price.

## Downloadable report

Use **Download report** in the dashboard to save `cloudspend-report.csv`. It includes usage rows, unit prices, estimated costs, budget, month-to-date spend and the forecast.

## Folder structure

```text
cloudspend/
├── data/
│   └── .gitkeep
├── public/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── src/
│   ├── costs.js
│   ├── server.js
│   └── store.js
├── test/
│   ├── costs.test.js
│   └── server.test.js
├── .gitignore
├── ARCHITECTURE.md
├── PROJECT_REPORT.md
├── VIVA_QUESTIONS.md
├── package.json
└── README.md
```

## Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md) for the component diagram, data flow and key calculation formulas.

## Limitations

- This is a single-user local demo, not production billing software.
- It uses a JSON file rather than a database; do not run multiple server processes against the same data file.
- There is no authentication, role-based access, cloud-provider API integration, currency conversion, tax, discounts or commitment pricing.
- Forecasting assumes the current average daily spend continues through the month. It is not a predictive model.
- Budget alerts appear in the dashboard; the app does not send email/SMS notifications.
- CSV import is capped at 5,000 rows per request.

## Troubleshooting

- If port 3000 is busy, use `PORT=3001 npm start` on macOS/Linux, or PowerShell `$env:PORT=3001; npm start` on Windows, then open `http://localhost:3001`.
- If the page does not load, confirm the terminal says CloudSpend is running and that the URL uses `localhost`.
- If pricing changes, all stored usage rows are recalculated with the new rate by design.
- Use **Reset demo data** to restore the original simulated records and default prices.
