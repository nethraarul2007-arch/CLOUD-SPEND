const test = require('node:test');
const assert = require('node:assert/strict');
const { costFor, summarize } = require('../src/costs');

const pricing = [
  { service: 'Compute', unit: 'hour', price: 0.08, currency: 'USD' },
  { service: 'Storage', unit: 'GB-day', price: 0.025, currency: 'USD' }
];

test('costFor multiplies quantity by configured unit price', () => {
  assert.equal(costFor({ service: 'Compute', quantity: 10 }, pricing), 0.8);
});

test('unknown service has zero cost in calculation helper', () => {
  assert.equal(costFor({ service: 'Other', quantity: 10 }, pricing), 0);
});

test('summary computes current day, month, budget use, forecast and chart series', () => {
  const now = new Date('2026-10-22T12:00:00Z');
  const state = {
    pricing, monthlyBudget: 10, alertThreshold: 80,
    usage: [
      { id: 'a', date: '2026-10-22', service: 'Compute', quantity: 10, unit: 'hour' },
      { id: 'b', date: '2026-10-21', service: 'Storage', quantity: 20, unit: 'GB-day' },
      { id: 'c', date: '2026-09-30', service: 'Compute', quantity: 100, unit: 'hour' }
    ]
  };
  const result = summarize(state, now);
  assert.equal(result.metrics.dailyCost, 0.8);
  assert.equal(result.metrics.monthlyCost, 1.3);
  assert.equal(result.metrics.remainingBudget, 8.7);
  assert.equal(result.metrics.dailyTotals.length, 7);
  assert.equal(result.metrics.forecast, 1.83);
  assert.equal(result.metrics.alert, null);
});

test('budget alert activates at configured threshold', () => {
  const state = { pricing, monthlyBudget: 1, alertThreshold: 80, usage: [{ date: '2026-10-22', service: 'Compute', quantity: 10 }] };
  const result = summarize(state, new Date('2026-10-22T12:00:00Z'));
  assert.equal(result.metrics.alert.level, 'warning');
});

test('budget alert identifies an exceeded budget', () => {
  const state = { pricing, monthlyBudget: 1, alertThreshold: 80, usage: [{ date: '2026-10-22', service: 'Compute', quantity: 20 }] };
  const result = summarize(state, new Date('2026-10-22T12:00:00Z'));
  assert.equal(result.metrics.alert.level, 'danger');
});
