const test = require('node:test');
const assert = require('node:assert/strict');
const { validateUsage } = require('../src/server');

const pricing = [{ service: 'Compute', unit: 'hour', price: 0.08 }];

test('valid usage is accepted', () => {
  assert.equal(validateUsage({ date: '2026-10-22', service: 'Compute', quantity: 3 }, pricing), null);
});
test('invalid dates are rejected', () => {
  assert.match(validateUsage({ date: '22/10/2026', service: 'Compute', quantity: 3 }, pricing), /YYYY-MM-DD/);
});
test('non-positive quantity is rejected', () => {
  assert.match(validateUsage({ date: '2026-10-22', service: 'Compute', quantity: 0 }, pricing), /positive number/);
});
test('service without configured pricing is rejected', () => {
  assert.match(validateUsage({ date: '2026-10-22', service: 'Unknown', quantity: 3 }, pricing), /configured pricing/);
});
