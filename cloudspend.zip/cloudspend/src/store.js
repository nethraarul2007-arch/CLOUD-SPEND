const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

const SAMPLE_PRICING = [
  { service: 'Compute', unit: 'hour', price: 0.08, currency: 'USD' },
  { service: 'Storage', unit: 'GB-day', price: 0.025, currency: 'USD' },
  { service: 'Database', unit: 'hour', price: 0.12, currency: 'USD' },
  { service: 'Data Transfer', unit: 'GB', price: 0.09, currency: 'USD' }
];

function sampleState() {
  const today = new Date();
  const day = (offset) => {
    const d = new Date(today);
    d.setDate(d.getDate() + offset);
    return d.toISOString().slice(0, 10);
  };
  return {
    pricing: SAMPLE_PRICING.map(x => ({ ...x })),
    monthlyBudget: 150,
    alertThreshold: 80,
    usage: [
      { id: 'sample-1', date: day(-6), provider: 'Demo Cloud', service: 'Compute', resource: 'web-vm-01', quantity: 18, unit: 'hour', region: 'us-east-1', note: 'SIMULATED sample data' },
      { id: 'sample-2', date: day(-5), provider: 'Demo Cloud', service: 'Storage', resource: 'assets-bucket', quantity: 22, unit: 'GB-day', region: 'us-east-1', note: 'SIMULATED sample data' },
      { id: 'sample-3', date: day(-4), provider: 'Demo Cloud', service: 'Database', resource: 'orders-db', quantity: 9, unit: 'hour', region: 'eu-west-1', note: 'SIMULATED sample data' },
      { id: 'sample-4', date: day(-3), provider: 'Demo Cloud', service: 'Compute', resource: 'worker-vm-02', quantity: 24, unit: 'hour', region: 'us-east-1', note: 'SIMULATED sample data' },
      { id: 'sample-5', date: day(-2), provider: 'Demo Cloud', service: 'Data Transfer', resource: 'outbound-traffic', quantity: 12, unit: 'GB', region: 'ap-south-1', note: 'SIMULATED sample data' },
      { id: 'sample-6', date: day(-1), provider: 'Demo Cloud', service: 'Compute', resource: 'web-vm-01', quantity: 20, unit: 'hour', region: 'us-east-1', note: 'SIMULATED sample data' },
      { id: 'sample-7', date: day(0), provider: 'Demo Cloud', service: 'Storage', resource: 'assets-bucket', quantity: 28, unit: 'GB-day', region: 'us-east-1', note: 'SIMULATED sample data' }
    ],
    updatedAt: new Date().toISOString()
  };
}

function ensureStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(STORE_PATH)) saveState(sampleState());
}

function loadState() {
  ensureStore();
  try {
    return JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
  } catch {
    const fresh = sampleState();
    saveState(fresh);
    return fresh;
  }
}

function saveState(state) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  state.updatedAt = new Date().toISOString();
  fs.writeFileSync(STORE_PATH, JSON.stringify(state, null, 2), 'utf8');
}

module.exports = { loadState, saveState, sampleState, SAMPLE_PRICING };
