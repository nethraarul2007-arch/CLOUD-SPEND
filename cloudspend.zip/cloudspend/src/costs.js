function costFor(entry, pricing) {
  const rate = pricing.find(p => p.service === entry.service);
  return rate ? Number((Number(entry.quantity) * Number(rate.price)).toFixed(4)) : 0;
}

function monthKey(dateString) {
  return String(dateString).slice(0, 7);
}

function summarize(state, now = new Date()) {
  const today = now.toISOString().slice(0, 10);
  const month = today.slice(0, 7);
  const usage = state.usage.map(entry => ({
    ...entry,
    unitPrice: (state.pricing.find(p => p.service === entry.service) || {}).price ?? null,
    cost: costFor(entry, state.pricing)
  }));
  const dailyCost = usage.filter(x => x.date === today).reduce((sum, x) => sum + x.cost, 0);
  const monthlyCost = usage.filter(x => monthKey(x.date) === month).reduce((sum, x) => sum + x.cost, 0);
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const dayNumber = now.getDate();
  const forecast = dayNumber > 0 ? monthlyCost / dayNumber * daysInMonth : 0;
  const dailyTotals = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    dailyTotals[d.toISOString().slice(0, 10)] = 0;
  }
  usage.forEach(x => {
    if (Object.prototype.hasOwnProperty.call(dailyTotals, x.date)) dailyTotals[x.date] += x.cost;
  });
  const serviceTotals = {};
  usage.filter(x => monthKey(x.date) === month).forEach(x => {
    serviceTotals[x.service] = (serviceTotals[x.service] || 0) + x.cost;
  });
  const budget = Number(state.monthlyBudget) || 0;
  const utilization = budget > 0 ? monthlyCost / budget * 100 : 0;
  let alert = null;
  if (budget > 0 && monthlyCost >= budget) {
    alert = { level: 'danger', message: `Budget exceeded by $${(monthlyCost - budget).toFixed(2)}.` };
  } else if (budget > 0 && utilization >= Number(state.alertThreshold)) {
    alert = { level: 'warning', message: `You have used ${utilization.toFixed(1)}% of your monthly budget.` };
  }
  return {
    usage,
    metrics: {
      today,
      month,
      dailyCost: Number(dailyCost.toFixed(2)),
      monthlyCost: Number(monthlyCost.toFixed(2)),
      monthlyBudget: budget,
      remainingBudget: Number((budget - monthlyCost).toFixed(2)),
      utilization: Number(utilization.toFixed(1)),
      forecast: Number(forecast.toFixed(2)),
      alert,
      dailyTotals: Object.entries(dailyTotals).map(([date, cost]) => ({ date, cost: Number(cost.toFixed(2)) })),
      serviceTotals: Object.entries(serviceTotals).map(([service, cost]) => ({ service, cost: Number(cost.toFixed(2)) })).sort((a, b) => b.cost - a.cost)
    }
  };
}

module.exports = { costFor, summarize };
