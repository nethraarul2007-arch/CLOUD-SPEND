const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { loadState, saveState, SAMPLE_PRICING } = require('./store');
const { summarize } = require('./costs');

const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const MAX_BODY = 2 * 1024 * 1024;
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml' };

function send(res, status, data, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' });
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > MAX_BODY) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('Invalid JSON body')); }
    });
    req.on('error', reject);
  });
}
function validDate(value) { return /^\d{4}-\d{2}-\d{2}$/.test(String(value)) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)); }
function cleanText(value, max = 100) { return String(value ?? '').trim().slice(0, max); }
function validateUsage(body, pricing) {
  const service = cleanText(body.service, 60);
  const price = pricing.find(p => p.service === service);
  if (!price) return 'Choose a service that has configured pricing.';
  const quantity = Number(body.quantity);
  if (!Number.isFinite(quantity) || quantity <= 0 || quantity > 1e9) return 'Quantity must be a positive number.';
  if (!validDate(body.date)) return 'Date must use YYYY-MM-DD format.';
  return null;
}
function serveStatic(req, res, pathname) {
  const requestPath = pathname === '/' ? '/index.html' : decodeURIComponent(pathname);
  const target = path.resolve(PUBLIC_DIR, `.${requestPath}`);
  if (!target.startsWith(PUBLIC_DIR + path.sep) && target !== path.join(PUBLIC_DIR, 'index.html')) return send(res, 403, { error: 'Forbidden path' });
  fs.readFile(target, (err, content) => {
    if (err) return send(res, 404, { error: 'Not found' });
    send(res, 200, content, MIME[path.extname(target)] || 'application/octet-stream');
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && url.pathname === '/api/state') {
      const state = loadState();
      return send(res, 200, { ...state, ...summarize(state) });
    }
    if (req.method === 'POST' && url.pathname === '/api/usage') {
      const body = await readBody(req);
      const state = loadState();
      const error = validateUsage(body, state.pricing);
      if (error) return send(res, 400, { error });
      const entry = {
        id: randomUUID(), date: body.date, provider: cleanText(body.provider || 'Custom', 80),
        service: cleanText(body.service, 60), resource: cleanText(body.resource || 'Unnamed resource', 100),
        quantity: Number(body.quantity), unit: state.pricing.find(p => p.service === body.service).unit,
        region: cleanText(body.region || 'Not specified', 60), note: cleanText(body.note, 200)
      };
      state.usage.push(entry);
      saveState(state);
      return send(res, 201, { entry, ...summarize(state) });
    }
    if (req.method === 'POST' && url.pathname === '/api/pricing') {
      const body = await readBody(req);
      const service = cleanText(body.service, 60);
      const price = Number(body.price);
      const unit = cleanText(body.unit, 30);
      if (!service || !unit || !Number.isFinite(price) || price < 0 || price > 1e6) return send(res, 400, { error: 'Enter a service, unit, and non-negative price.' });
      const state = loadState();
      const existing = state.pricing.find(p => p.service.toLowerCase() === service.toLowerCase());
      if (existing) { existing.price = price; existing.unit = unit; }
      else state.pricing.push({ service, unit, price, currency: 'USD' });
      saveState(state);
      return send(res, 200, { ...state, ...summarize(state) });
    }
    if (req.method === 'POST' && url.pathname === '/api/budget') {
      const body = await readBody(req);
      const monthlyBudget = Number(body.monthlyBudget);
      const alertThreshold = Number(body.alertThreshold);
      if (!Number.isFinite(monthlyBudget) || monthlyBudget < 0 || monthlyBudget > 1e9 || !Number.isFinite(alertThreshold) || alertThreshold < 1 || alertThreshold > 100) {
        return send(res, 400, { error: 'Budget must be non-negative and alert threshold must be between 1 and 100.' });
      }
      const state = loadState();
      state.monthlyBudget = monthlyBudget;
      state.alertThreshold = alertThreshold;
      saveState(state);
      return send(res, 200, { ...state, ...summarize(state) });
    }
    if (req.method === 'POST' && url.pathname === '/api/import') {
      const body = await readBody(req);
      if (!Array.isArray(body.rows) || body.rows.length > 5000) return send(res, 400, { error: 'Import must contain an array of up to 5,000 rows.' });
      const state = loadState();
      const errors = [];
      const imported = [];
      body.rows.forEach((row, index) => {
        const error = validateUsage(row, state.pricing);
        if (error) { errors.push({ row: index + 1, error }); return; }
        imported.push({
          id: randomUUID(), date: row.date, provider: cleanText(row.provider || 'CSV import', 80),
          service: cleanText(row.service, 60), resource: cleanText(row.resource || 'Imported resource', 100),
          quantity: Number(row.quantity), unit: state.pricing.find(p => p.service === row.service).unit,
          region: cleanText(row.region || 'Not specified', 60), note: cleanText(row.note || 'Imported from CSV', 200)
        });
      });
      state.usage.push(...imported);
      saveState(state);
      return send(res, 200, { imported: imported.length, errors: errors.slice(0, 100), ...summarize(state) });
    }
    if (req.method === 'POST' && url.pathname === '/api/reset') {
      const state = require('./store').sampleState();
      saveState(state);
      return send(res, 200, { ...state, ...summarize(state) });
    }
    if (req.method === 'GET' && url.pathname.startsWith('/api/')) return send(res, 404, { error: 'API route not found' });
    if (req.method === 'GET') return serveStatic(req, res, url.pathname);
    return send(res, 405, { error: 'Method not allowed' });
  } catch (error) {
    if (!res.headersSent) send(res, 400, { error: error.message || 'Request failed' });
  }
});

if (require.main === module) {
  server.listen(PORT, () => console.log(`CloudSpend is running at http://localhost:${PORT}`));
}
module.exports = { server, validateUsage };
