const $ = (selector) => document.querySelector(selector);
let appState = null;
const money = (value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(value || 0));
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function showNotice(message, isError = false) {
  const el = $('#notice');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.classList.remove('hidden');
  window.clearTimeout(showNotice.timer);
  showNotice.timer = window.setTimeout(() => el.classList.add('hidden'), 5000);
}
async function api(path, payload) {
  const response = await fetch(path, payload ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) } : {});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
async function refresh() {
  try { appState = await api('/api/state'); render(); }
  catch (error) { showNotice(error.message, true); }
}
function render() {
  if (!appState) return;
  const m = appState.metrics;
  $('#monthLabel').textContent = new Date(`${m.month}-01T12:00:00`).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  $('#dailyCost').textContent = money(m.dailyCost);
  $('#monthlyCost').textContent = money(m.monthlyCost);
  $('#remainingBudget').textContent = money(m.remainingBudget);
  $('#budgetCaption').textContent = `of ${money(m.monthlyBudget)} monthly budget`;
  $('#forecast').textContent = money(m.forecast);
  $('#monthlyBudgetInput').value = m.monthlyBudget;
  $('#alertThresholdInput').value = appState.alertThreshold;
  const banner = $('#alertBanner');
  if (m.alert) {
    banner.textContent = `Budget alert · ${m.alert.message}`;
    banner.className = `alert-banner ${m.alert.level === 'danger' ? 'danger' : ''}`;
    banner.classList.remove('hidden');
  } else banner.classList.add('hidden');
  $('#serviceSelect').innerHTML = appState.pricing.map(p => `<option value="${escapeHtml(p.service)}">${escapeHtml(p.service)} — ${escapeHtml(p.unit)}</option>`).join('');
  $('#pricingList').innerHTML = appState.pricing.map(p => `<span class="price-chip"><strong>${escapeHtml(p.service)}</strong> · ${money(p.price)}/${escapeHtml(p.unit)}</span>`).join('');
  renderBreakdown(m.serviceTotals);
  renderDailyChart(m.dailyTotals);
  const entries = [...appState.usage].sort((a,b) => b.date.localeCompare(a.date)).slice(0, 100);
  $('#usageRows').innerHTML = entries.map(row => {
    const isSample = String(row.note || '').includes('SIMULATED');
    return `<tr><td>${escapeHtml(row.date)}</td><td class="service-cell"><strong>${escapeHtml(row.service)}</strong><span>${escapeHtml(row.resource || 'Unnamed resource')}</span></td><td>${escapeHtml(row.provider || 'Custom')}<br><span class="service-cell">${escapeHtml(row.region || '')}</span></td><td>${Number(row.quantity).toLocaleString()} ${escapeHtml(row.unit)}</td><td>${row.unitPrice == null ? '—' : money(row.unitPrice)}</td><td class="cost-cell">${money(row.cost)}</td><td>${escapeHtml(row.note || '—')}${isSample ? '<span class="simulated-tag">SIMULATED</span>' : ''}</td></tr>`;
  }).join('') || '<tr><td colspan="7">No usage records yet. Add a record to begin.</td></tr>';
  $('#recordCount').textContent = `Showing ${entries.length} of ${appState.usage.length} records · Values are estimates in USD.`;
}
function renderBreakdown(items) {
  const root = $('#serviceBreakdown');
  if (!items.length) { root.innerHTML = '<p class="empty-state">No usage for this month yet.</p>'; return; }
  const max = Math.max(...items.map(x => x.cost), 0.01);
  root.innerHTML = items.map(item => `<div class="breakdown-item"><span class="breakdown-name">${escapeHtml(item.service)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.max(2, item.cost/max*100)}%"></div></div><span class="breakdown-value">${money(item.cost)}</span></div>`).join('');
}
function renderDailyChart(items) {
  const canvas = $('#dailyChart');
  const rect = canvas.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.max(300, rect.width * ratio);
  canvas.height = Math.max(160, rect.height * ratio);
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio);
  const w = canvas.width / ratio, h = canvas.height / ratio;
  ctx.clearRect(0, 0, w, h);
  const pad = { left: 39, right: 10, top: 14, bottom: 28 };
  const chartW = w-pad.left-pad.right, chartH = h-pad.top-pad.bottom;
  const max = Math.max(0.1, ...items.map(x => x.cost)) * 1.2;
  ctx.font = '10px DM Sans, sans-serif';
  ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  for (let i=0;i<=3;i++) {
    const y = pad.top + chartH*i/3;
    ctx.strokeStyle = '#edf1f4'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad.left,y); ctx.lineTo(w-pad.right,y); ctx.stroke();
    ctx.fillStyle = '#8b97a0'; ctx.fillText(money(max*(1-i/3)).replace('.00',''), pad.left-7, y);
  }
  const slot = chartW / Math.max(1, items.length);
  items.forEach((item,i) => {
    const barW = Math.min(30, slot*0.55);
    const barH = item.cost/max*chartH;
    const x = pad.left+i*slot+(slot-barW)/2;
    const y = pad.top+chartH-barH;
    ctx.fillStyle = i === items.length-1 ? '#167d78' : '#b6dcd7';
    ctx.beginPath();
    const r = Math.min(5,barW/2);
    ctx.roundRect(x,y,barW,Math.max(2,barH),[r,r,0,0]);
    ctx.fill();
    ctx.fillStyle = '#7b8993'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(new Date(`${item.date}T12:00:00`).toLocaleDateString(undefined,{weekday:'short'}),x+barW/2,h-pad.bottom+8);
  });
}
function download(name, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}
function csvEscape(value) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g,'""')}"` : text;
}
function exportReport() {
  const state = appState;
  if (!state) return;
  const rows = [['Date','Provider','Service','Resource','Quantity','Unit','Unit Price USD','Estimated Cost USD','Region','Note']];
  [...state.usage].sort((a,b)=>a.date.localeCompare(b.date)).forEach(x => rows.push([x.date,x.provider,x.service,x.resource,x.quantity,x.unit,x.unitPrice ?? '',x.cost,x.region,x.note]));
  rows.push([]);
  rows.push(['Monthly budget USD', state.monthlyBudget]);
  rows.push(['Month-to-date cost USD', state.metrics.monthlyCost]);
  rows.push(['Month-end forecast USD', state.metrics.forecast]);
  rows.push(['Pricing note', 'Sample estimates only; not actual cloud-provider rates']);
  download('cloudspend-report.csv', rows.map(r=>r.map(csvEscape).join(',')).join('\r\n'), 'text/csv;charset=utf-8');
}
function parseCSV(text) {
  const rows=[]; let row=[], field='', quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){ if(c==='"' && text[i+1]==='"'){field+='"';i++;} else if(c==='"') quoted=false; else field+=c; }
    else if(c==='"') quoted=true;
    else if(c===','){row.push(field);field='';}
    else if(c==='\n'){row.push(field.replace(/\r$/,''));rows.push(row);row=[];field='';}
    else field+=c;
  }
  if(field.length || row.length){row.push(field.replace(/\r$/,''));rows.push(row);}
  if(!rows.length) return [];
  const headers=rows.shift().map(h=>h.trim().toLowerCase().replace(/[\s_-]+/g,''));
  const idx=(...names)=>headers.findIndex(h=>names.includes(h));
  const dateI=idx('date'), serviceI=idx('service'), quantityI=idx('quantity','qty');
  if(dateI<0 || serviceI<0 || quantityI<0) throw new Error('CSV needs date, service, and quantity columns.');
  return rows.filter(r=>r.some(v=>v.trim())).map(r=>({
    date:r[dateI], service:r[serviceI], quantity:Number(r[quantityI]),
    provider:r[idx('provider','cloudprovider')] ?? 'CSV import',
    resource:r[idx('resource','resourcename')] ?? 'Imported resource',
    region:r[idx('region')] ?? 'Not specified',
    note:r[idx('note')] ?? 'Imported from CSV'
  }));
}
$('#usageDate').value = new Date().toISOString().slice(0,10);
$('#usageForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = Object.fromEntries(form.entries());
  payload.quantity = Number(payload.quantity);
  try { await api('/api/usage', payload); event.currentTarget.reset(); $('#usageDate').value = new Date().toISOString().slice(0,10); await refresh(); showNotice('Usage record added.'); }
  catch(error){showNotice(error.message,true);}
});
$('#budgetForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=new FormData(event.currentTarget);
  try { await api('/api/budget',{monthlyBudget:Number(form.get('monthlyBudget')),alertThreshold:Number(form.get('alertThreshold'))}); await refresh(); showNotice('Budget settings saved.'); }
  catch(error){showNotice(error.message,true);}
});
$('#pricingForm').addEventListener('submit', async event => {
  event.preventDefault(); const form=new FormData(event.currentTarget);
  try { await api('/api/pricing',{service:form.get('service'),unit:form.get('unit'),price:Number(form.get('price'))}); event.currentTarget.reset(); await refresh(); showNotice('Pricing saved. Existing records were recalculated.'); }
  catch(error){showNotice(error.message,true);}
});
$('#downloadReport').addEventListener('click',exportReport);
$('#csvInput').addEventListener('change', async event => {
  const file=event.target.files[0]; if(!file)return;
  try {
    const rows=parseCSV(await file.text());
    if(!rows.length) throw new Error('No data rows found in the CSV.');
    const result=await api('/api/import',{rows});
    await refresh();
    showNotice(`Imported ${result.imported} row(s). ${result.errors.length} row(s) skipped. Check service names and dates if rows were skipped.`);
  } catch(error){showNotice(error.message,true);}
  event.target.value='';
});
$('#resetDemo').addEventListener('click', async () => {
  if(!window.confirm('Reset all usage and pricing changes to the original simulated demo data?')) return;
  try { await api('/api/reset',{}); await refresh(); showNotice('Demo data restored.'); }
  catch(error){showNotice(error.message,true);}
});
window.addEventListener('resize',()=>{if(appState)renderDailyChart(appState.metrics.dailyTotals);});
refresh();
