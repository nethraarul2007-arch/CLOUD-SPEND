# Project Report: CloudSpend
## Cloud Usage Cost Estimation and Budget Alert System

### 1. Abstract
CloudSpend is a browser-based prototype for estimating cloud resource costs and monitoring a monthly budget. Users record resource consumption, configure a price per unit, and view daily and month-to-date estimates. The dashboard presents a seven-day chart, a service-level cost breakdown, a simple month-end forecast, and budget-threshold alerts. CSV import and report export support basic data exchange. The prototype uses HTML, CSS, JavaScript, and Node.js built-in modules without third-party runtime dependencies.

### 2. Problem statement
Cloud usage can span multiple services and units, making it difficult for learners or small teams to understand how consumption affects cost. A simple estimation dashboard can make resource usage visible and help users identify when spending approaches a budget limit. The prototype demonstrates the workflow without accessing real cloud billing data.

### 3. Objectives
- Record cloud usage with date, service, quantity, resource and region.
- Allow prices per service unit to be configured.
- Estimate daily and monthly cost.
- Display budget utilization and show warnings at a configurable threshold.
- Present recent trends and service-level cost distribution.
- Estimate month-end spend using a basic run-rate method.
- Import usage from CSV and download a cost report.
- Validate input and test core calculation logic.

### 4. Technology stack
- **HTML5:** dashboard structure and forms.
- **CSS3:** responsive layout and visual styling.
- **JavaScript:** dashboard rendering, chart drawing, CSV parsing and report download.
- **Node.js built-in modules:** HTTP server, filesystem persistence, UUID generation and automated tests.
- **JSON:** local persistence format.

### 5. System design
The browser communicates with a Node.js HTTP server through JSON endpoints. The server validates incoming usage, pricing and budget data, persists accepted changes to a JSON file, and returns calculated summaries. A separate cost module calculates per-entry cost, daily totals, month-to-date spend, budget utilization and forecast. The browser renders the results and can create a CSV report locally.

### 6. Functional modules
1. **Usage entry:** stores date, provider, service, resource, quantity, region and note.
2. **Pricing management:** adds a service or updates its unit and unit price. Changing a price recalculates historical entries using the current price.
3. **Cost summary:** calculates daily and calendar-month estimates.
4. **Budget alerts:** warns when the configured utilization threshold is reached or the budget is exceeded.
5. **Visual analytics:** draws a seven-day bar chart and service-level horizontal bars.
6. **Forecast:** projects month-end cost from the current average daily spend.
7. **CSV import:** accepts rows with date, service and quantity, with optional descriptive fields.
8. **Report export:** downloads usage records, unit prices, estimated costs, budget and forecast as CSV.
9. **Persistence:** stores state in `data/store.json`.

### 7. Calculation methods
For each usage entry:

`Estimated entry cost = quantity × configured price per unit`

Daily cost is the sum of costs for entries dated today. Month-to-date cost sums entries within the current calendar month. Budget utilization is month-to-date cost divided by the monthly budget and multiplied by 100. The forecast is month-to-date cost divided by the current day number, multiplied by the number of days in that month.

### 8. Sample data and assumptions
Initial usage entries and prices are simulated examples. The rates are illustrative placeholders in USD and must not be interpreted as current prices from AWS, Microsoft Azure, Google Cloud or another provider. The system has no live cloud connection. The forecast assumes spending remains at the current average daily rate for the rest of the month.

### 9. Testing
Automated tests use Node.js's built-in `node:test` and `node:assert/strict` modules. They verify unit-cost arithmetic, unknown-service handling in the calculation helper, daily and monthly totals, forecast output, threshold and over-budget alerts, and usage-field validation. Run the suite using `npm test`.

### 10. Limitations and future enhancements
The prototype is single-user and uses a local JSON file. It has no login, database, cloud billing API, notifications, tax or discount calculation. Future work could add a database, authentication, actual provider billing imports, budget alerts by email, multi-currency support, cost anomaly detection, tagging, and role-based access.

### 11. Conclusion
CloudSpend demonstrates the basic workflow of recording usage, estimating cost, tracking a budget, viewing trends and exporting results. It provides a simple foundation for learning cloud cost management while clearly distinguishing simulated estimates from real billing data.
